package test;

import java.util.Scanner;

public class Test {
public static Scanner sc = new Scanner(System.in);
    public static int pole[];
    public static void main(String[] args) 
    {

        System.out.println("Zvolte liche cislo velikosti pyramidy: ");
        String vyber = sc.nextLine();
        int velikost = Integer.parseInt(vyber);
        if(velikost % 2 == 0)
        {
            System.out.println("Nezadal jste liche cislo.");
        }
        else
        {
           Pyramida(velikost); 
        }
    }
    public static void Pyramida(int velikost)
    {
        int x = velikost;
        int jednicka = 1;
        for(int i=0;i<velikost;i++){
            for(int j=0;j<2*velikost-i-1;j++){
                if(i>j){
                    System.out.print(" ");
                }else{
                    System.out.print(jednicka);
                }
            }
            System.out.println();
        }
        System.out.println();
    }
}
        
        
        
        
                

        
            
      
        


